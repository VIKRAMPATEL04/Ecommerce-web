
forget-password UI update --- Done
password -regEx --- Done
expire data --- Done
product stock --- Done
add sub-category --- Done
manage sub-category --- Done
manage product --- Done



fix in forget password --- Done
bulk entry --- Done
check-out --- Done
edit-sub-category --- Done
invoice --- Done
Add product photo --- Done
product photo update --- Done
bulk entry>add sample excel file for download --- Done
manage product > renew a stock --- Done
add Product > fix in expire require or not --- Done
edit-product > expire date updatetion  --- Done
dashboard > number of products who expire within 7 days show number --- Done
dashboard > Near ExpiryDate page open product list --- Done
dashboard > number of products who stock-out only 5 qty left show number --- Done
dashboard > Near StockOut page open product list --- Done
dashboard > click card and open page --- Done
manage Product > fix in expire date at edit --- Done
bulk-company-add --- Done
bulk entry-do not add duplicate entry --- Done
Add Product Stock Data For Any Perticular Store --- Done
invoice > download invoice pdf --- Done


******************************** Multi User App **************************************************************
big change:-  make app able to store multi user data-create table for Perticular Store

add userID in session at login time with name 'aid' --- Done

dashboard > Category --- Done
            sub-Category --- Done
            company --- Done
            product --- Done
            all Sales --- Done
            near ExpiryDate --- Done
            near StockOut --- Done

Category >  Add  --- Done
            manage category --- Done
            manage sub-category --- Done

company >   add --- Done
            bulk-company-add --- Done
            manage company --- Done

product >   add --- Done
            bulk-add --- Done 
            manage --- Done

product Sales > checkout --- Done
                Search --- Done

invoice --- Done
Reports > b/w dates --- Done

navbar > profile --- Done

dashboard > Category --- Done
            sub-Category --- Done
            company --- Done
            product --- Done
            all Sales --- Done
            near ExpiryDate --- Done
            near StockOut --- Done

dashboard > open page >  near ExpiryDate --- Done
                         near StockOut --- Done

*************************************************************************************************************

SignUp > email make unique --- Done
bulk-add product > only xlsx file will be accepted --- Done
invoice printing updated --- Done
dashboard   >   Near ExpiryDate & Near StockOut >>  if > 0 so card color is RED ---- Done
bulk-product import if in excel filled missing so get alert --- Done
product Sales > checkout > mobile_number validation fix --- Done
profile > Update only Shop owner name, shop name --- Done


product sales > cart > fix deselect product

manage product > bulk delete



// get past orders list in excel-sheet

// get current product inventory in excel-sheet

product sales > search product name add AJAX

Add Product > add AJAX in Subcategory 


************ GST ************

update excel file with add filled GST %

add product > add GST percentage filled

view-invoice > GST Breakup Details table ---

manage product > update GST percentage filled


*************************************************************************************************

fix near expiredate in deshboard  --- Done

cart product stock --- Done

fix cart  --- Done

mobile_number validation in SignUp --- Done

add-sub-category page --- Done

add gst data otherwise remove all gst related UI --- 